"""SQLModel models for database tables and API payloads."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel
from sqlmodel import SQLModel, Field


class SessionState(str, Enum):
    """Lifecycle states for a supervised session."""
    CREATED = "CREATED"
    RUNNING = "RUNNING"
    AWAITING_INPUT = "AWAITING_INPUT"
    INTERRUPTING = "INTERRUPTING"
    ERROR = "ERROR"


class ExternalRunnerType(str, Enum):
    """Types of external session sources."""
    CLAUDE_CODE = "claude_code"
    CODEX_CLI = "codex_cli"


class ExternalSessionMessage(BaseModel):
    """Normalized message from external session history."""
    role: str  # "user" or "assistant"
    content: str
    thinking: str | None = None
    timestamp: str | None = None


class ExternalSessionSummary(BaseModel):
    """Summary info for an external session (for list view)."""
    id: str
    runner_type: ExternalRunnerType
    directory: str
    first_prompt: str | None = None
    last_activity: str
    message_count: int
    is_running: bool


class ExternalSessionDetail(ExternalSessionSummary):
    """Full external session with message history."""
    messages: list[ExternalSessionMessage] = []


class RepoRef(BaseModel):
    """Reference to a repository target (path or URL)."""
    type: str
    value: str


class ErrorDetail(BaseModel):
    """Structured error payload for API responses."""
    code: str
    message: str
    details: dict | None


class ErrorResponse(BaseModel):
    """Envelope for API error responses."""
    error: ErrorDetail


# --- Database Tables (SQLModel with table=True) ---


class Session(SQLModel, table=True):
    """Session table and API model."""
    __tablename__ = "sessions"

    id: str = Field(primary_key=True)
    repo_id: str
    repo_display: str
    repo_ref_type: str
    repo_ref_value: str
    state: SessionState
    name: Optional[str] = None
    created_at: str
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    last_activity_at: str
    exit_code: Optional[int] = None
    summary: Optional[str] = None
    runner_header: Optional[str] = None
    runner_type: Optional[str] = None
    runner_session_id: Optional[str] = Field(default=None, unique=True)
    directory: Optional[str] = None
    directory_has_git: bool = False
    workdir_managed: bool = False

    @property
    def repo_ref(self) -> RepoRef:
        """Get repo_ref as a RepoRef object."""
        return RepoRef(type=self.repo_ref_type, value=self.repo_ref_value)

    @repo_ref.setter
    def repo_ref(self, value: RepoRef) -> None:
        """Set repo_ref from a RepoRef object."""
        self.repo_ref_type = value.type
        self.repo_ref_value = value.value


class Message(SQLModel, table=True):
    """Message table and API model."""
    __tablename__ = "messages"

    id: str = Field(primary_key=True)
    session_id: str = Field(foreign_key="sessions.id", ondelete="CASCADE")
    role: str
    content: Optional[str] = None
    created_at: str
    seq: int
